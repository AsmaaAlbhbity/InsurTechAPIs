export class Googlelogin {
    constructor(public Email :string ){

    }
}
