export interface RegisterData {
  name: string;
  userName: string;
  emailAddress: string;
  password: string;
  taxNumber: string;
  location: string;
  phoneNumber: string;
}
