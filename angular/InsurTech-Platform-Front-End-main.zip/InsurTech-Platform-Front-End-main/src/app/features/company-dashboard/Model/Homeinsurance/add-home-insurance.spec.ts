import { AddHomeInsurance } from './add-home-insurance';

describe('AddHomeInsurance', () => {
  it('should create an instance', () => {
    expect(new AddHomeInsurance()).toBeTruthy();
  });
});
