export class Question {
    constructor(
        public id: number,
        public body: string,
        public categoryId: number
    ){}
}