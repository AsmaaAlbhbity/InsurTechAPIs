import { EditHomeInsurance } from './edit-home-insurance';

describe('EditHomeInsurance', () => {
  it('should create an instance', () => {
    expect(new EditHomeInsurance()).toBeTruthy();
  });
});
