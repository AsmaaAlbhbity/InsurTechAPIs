export class EditHomeInsurance {
    constructor(public id:number,public yearlyCoverage:number,public level:number,public quotation:number,public companyId:string,public waterDamage:number,public glassBreakage:number ,public naturalHazard:number,public attemptedTheft:number,public firesAndExplosion:number){
  
    }
}
