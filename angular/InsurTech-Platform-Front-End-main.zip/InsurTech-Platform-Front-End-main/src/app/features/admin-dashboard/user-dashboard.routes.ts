// import { Routes } from '@angular/router';
// import { RegistrationRequestsComponent } from './components/registration-requests/registration-requests.component';
// import { ArticleComponent } from './components/article/article.component';
// import { AppLayoutComponent } from './layout/app.layout.component';
// import { authAdminGuard } from '../../core/guards/authAdmin.guard';
// import { AdminCrudUsersComponent } from './components/admin-crud/admin-crud-users.component';
// import { ChartPieDemo } from './components/admin-graphs/admin-graphs.component';

// export const userDashboardRoutes: Routes = [
//   { path: '', component: AppLayoutComponent,
//         children: [
//             { path: 'registration-requests', component: RegistrationRequestsComponent, },
//             { path: 'article', component: ArticleComponent, },
//             { path: 'crud', component: AdminCrudUsersComponent },
//             {path:'dashboard',component:ChartPieDemo}
//         ]
//     },
// ];
