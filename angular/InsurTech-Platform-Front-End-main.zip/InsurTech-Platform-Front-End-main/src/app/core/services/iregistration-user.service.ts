export interface registerUser {
  name: string;
  userName: string;
  emailAddress: string;
  password: string;
  nationalId: string;
  birthDate: string;
  phoneNumber: string;
}
