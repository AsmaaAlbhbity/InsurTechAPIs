// import { AddHealthInsurance } from './add-health-insurance';

// describe('AddHealthInsurance', () => {
//   it('should create an instance', () => {
//     expect(new AddHealthInsurance()).toBeTruthy();
//   });
// });
