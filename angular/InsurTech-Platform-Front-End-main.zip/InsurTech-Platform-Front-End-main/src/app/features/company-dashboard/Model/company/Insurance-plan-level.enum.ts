export enum InsurancePlanLevel {
    Basic,
    Standard,
    Premium
  }
  