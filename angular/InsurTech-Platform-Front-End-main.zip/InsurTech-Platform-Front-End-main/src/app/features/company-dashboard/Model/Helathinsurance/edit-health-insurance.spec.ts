import { EditHealthInsurance } from './edit-health-insurance';

describe('EditHealthInsurance', () => {
  it('should create an instance', () => {
    expect(new EditHealthInsurance()).toBeTruthy();
  });
});
