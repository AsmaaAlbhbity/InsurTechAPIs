import { StatusLabelPipe } from './status-label.pipe';

describe('StatusLabelPipe', () => {
  it('create an instance', () => {
    const pipe = new StatusLabelPipe();
    expect(pipe).toBeTruthy();
  });
});
