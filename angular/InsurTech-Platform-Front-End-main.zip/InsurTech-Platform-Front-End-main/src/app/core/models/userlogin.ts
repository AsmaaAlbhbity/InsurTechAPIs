export class Userlogin {

    constructor( public email:string,public password:string){

    }
}
