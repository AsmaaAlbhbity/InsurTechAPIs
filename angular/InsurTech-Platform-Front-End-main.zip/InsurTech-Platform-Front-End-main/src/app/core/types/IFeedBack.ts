export interface IFeedBack {
  insurancePlanId: number;
  rating: number;
  comment: string;
}
