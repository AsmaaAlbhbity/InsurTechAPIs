export class Resetpassword {
    constructor(email:string,token:string,password:string){

    }
}
