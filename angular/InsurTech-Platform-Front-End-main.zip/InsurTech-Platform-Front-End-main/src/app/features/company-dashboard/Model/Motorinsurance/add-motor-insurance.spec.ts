import { AddMotorInsurance } from './add-motor-insurance';

describe('AddMotorInsurance', () => {
  it('should create an instance', () => {
    expect(new AddMotorInsurance()).toBeTruthy();
  });
});
