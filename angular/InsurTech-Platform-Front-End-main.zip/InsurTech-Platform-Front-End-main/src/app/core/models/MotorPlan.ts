export class HealthPlan {
    constructor(
       
    ) {}
}
