export class EditMotorInsurance {
    constructor(public id:number,public yearlyCoverage:number,public level:number,public quotation:number,public CompanyId:string,public personalAccident:number,public theft:number,public thirdPartyLiability:number,public ownDamage:number ,public legalExpenses:number){
  
    }
}
