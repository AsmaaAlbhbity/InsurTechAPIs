export class Forgotpassword {
    constructor(public email:string){

    }
}
