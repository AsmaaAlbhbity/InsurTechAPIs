export class Categories {
    constructor(
        public name: string,
        public description: string,
        public count: number
    ){}
}
