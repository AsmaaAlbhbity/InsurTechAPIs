import { EditMotorInsurance } from './edit-motor-insurance';

describe('EditMotorInsurance', () => {
  it('should create an instance', () => {
    expect(new EditMotorInsurance()).toBeTruthy();
  });
});
