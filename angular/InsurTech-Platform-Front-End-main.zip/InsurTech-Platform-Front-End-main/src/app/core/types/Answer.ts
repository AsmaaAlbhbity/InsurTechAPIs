// answer type
export type Answer = {
  questionId: number;
  answer: string;
};
