import { Component } from '@angular/core';

@Component({
  selector: 'app-page-a',
  standalone: true,
  imports: [],
  templateUrl: './page-a.component.html',
  styleUrl: './page-a.component.css'
})
export class PageAComponent {

}
