import { LevelInsurancePipe } from './level-insurance.pipe';

describe('LevelInsurancePipe', () => {
  it('create an instance', () => {
    const pipe = new LevelInsurancePipe();
    expect(pipe).toBeTruthy();
  });
});
