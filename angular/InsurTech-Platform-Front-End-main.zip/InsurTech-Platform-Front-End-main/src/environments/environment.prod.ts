export const environment = {
    production: true,
    apiUrl: 'https://insurtechapis.runasp.net/api'
};